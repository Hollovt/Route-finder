﻿//This file Can be modified

using BigTask2.Data;

namespace BigTask2.Interfaces
{
    interface IRouteProblem
	{
        IGraphDatabase Graph { get; set; }
	}
}

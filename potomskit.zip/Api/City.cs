﻿//This file should not be modified

namespace BigTask2.Api
{
    public class City
    {
        public string Name { get; set; }
        public int Population { get; set; }
        public bool HasRestaurant { get; set; }
    }
}

﻿//This file should not be modified

namespace BigTask2.Api
{
    public enum VehicleType
    {
        Car, Train
    }
}
